# General Tip
Use buckets instead of hose pipes.