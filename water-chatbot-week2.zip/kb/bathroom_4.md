# Bathroom Tip
Take shorter showers.