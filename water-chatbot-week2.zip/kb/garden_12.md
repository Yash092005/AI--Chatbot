# Garden Tip
Collect rainwater for garden use.