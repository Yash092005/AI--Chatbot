# Garden Tip
Water plants in early morning.