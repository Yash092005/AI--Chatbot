# Kitchen Tip
Run dishwasher only when full.