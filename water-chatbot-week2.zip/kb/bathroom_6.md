# Bathroom Tip
Install low-flow showerheads.