# Garden Tip
Use drip irrigation system.