# Laundry Tip
Reuse towel before washing.