# General Tip
Educate family members about water saving.