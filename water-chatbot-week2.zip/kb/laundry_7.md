# Laundry Tip
Run washing machine only with full loads.