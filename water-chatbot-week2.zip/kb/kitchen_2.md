# Kitchen Tip
Use a bowl to rinse fruits.