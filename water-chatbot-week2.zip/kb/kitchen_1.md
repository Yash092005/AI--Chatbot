# Kitchen Tip
Turn off tap when washing vegetables.