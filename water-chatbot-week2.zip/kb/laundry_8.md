# Laundry Tip
Use eco-mode to save water.