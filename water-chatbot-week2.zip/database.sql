
-- Database Schema for Water Chatbot (Week 2)
CREATE TABLE IF NOT EXISTS household (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    members INTEGER NOT NULL,
    avg_shower_time INTEGER,
    kitchen_usage INTEGER,
    laundry_usage INTEGER
);

CREATE TABLE IF NOT EXISTS usage_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    household_id INTEGER,
    daily_usage REAL,
    advice TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(household_id) REFERENCES household(id)
);
