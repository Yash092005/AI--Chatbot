# AI Chatbot for Water Conservation Awareness 🌍💧

## Week 2 Deliverables

### ✅ Features Implemented
- **Water Calculator Module (`calc.py`)**
- **Knowledge Base with 20+ water saving tips**
- **Knowledge Base Search Logic (`kb_search.py`)**
- **Backend Integration with Flask API**

### 📂 Project Structure
```
backend/
  ├── app.py          # Flask app with /ask and /calculate endpoints
  ├── calc.py         # Water calculator
  ├── kb_search.py    # Knowledge base search
kb/
  ├── kitchen_1.md    # Example water saving tips
  ├── bathroom_1.md   # ...
database.sql          # SQLite schema
README.md             # Project readme
report.pdf            # Submission report
```

### 🚀 How to Run
```bash
cd backend
pip install flask
python app.py
```

### 📊 API Endpoints
- `POST /ask` → Get chatbot response from knowledge base
- `POST /calculate` → Calculate household water usage & get tips

---
