import os

def search_tip(query):
    folder = os.path.join(os.path.dirname(__file__), "..", "kb")
    query = query.lower()
    for filename in os.listdir(folder):
        if filename.endswith(".md"):
            with open(os.path.join(folder, filename), "r", encoding="utf-8") as f:
                content = f.read().lower()
                if query in content:
                    return content.split("\n")[0]  # return first line as summary
    return "Sorry, I have no tips for that topic yet."
