from flask import Flask, request, jsonify
from calc import calculate_usage
from kb_search import search_tip

app = Flask(__name__)

@app.route('/ask', methods=['POST'])
def ask():
    data = request.get_json()
    query = data.get("query", "")
    response = search_tip(query)
    return jsonify({"query": query, "response": response})

@app.route('/calculate', methods=['POST'])
def calculate():
    data = request.get_json()
    members = data.get("members", 1)
    shower_time = data.get("shower_time", 5)
    kitchen = data.get("kitchen", 20)
    laundry = data.get("laundry", 30)

    usage, tip = calculate_usage(members, shower_time, kitchen, laundry)
    return jsonify({"daily_usage_liters": usage, "advice": tip})

if __name__ == '__main__':
    app.run(debug=True)
