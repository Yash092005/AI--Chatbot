def calculate_usage(members, shower_time, kitchen, laundry):
    # Estimate daily water usage
    shower_usage = members * shower_time * 9   # 9 liters/min shower
    kitchen_usage = kitchen * 5                # 5 liters per kitchen use
    laundry_usage = laundry                    # assume liters directly
    total = shower_usage + kitchen_usage + laundry_usage

    # Simple advice
    if shower_time > 7:
        advice = "Try reducing shower time to save ~20 liters per person."
    elif kitchen > 30:
        advice = "Consider washing dishes in a bowl instead of running tap."
    else:
        advice = "Good job! You're already conserving water."

    return total, advice
